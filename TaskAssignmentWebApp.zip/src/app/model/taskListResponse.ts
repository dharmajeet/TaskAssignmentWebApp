export interface TaskResponse{
    Id:number,
    Subject: string,
    Description: string,
    Comments:string,
    FollowupDate:any    ,
    IsSatisfied:any,
    CreatedAt:any,
    UpdatedAt:any
}