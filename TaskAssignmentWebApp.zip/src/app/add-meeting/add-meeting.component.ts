import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-add-meeting',
  templateUrl: './add-meeting.component.html',
  styleUrls: ['./add-meeting.component.scss']
})
export class AddMeetingComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
